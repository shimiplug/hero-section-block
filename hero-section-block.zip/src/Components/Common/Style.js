

const Style = ({ attributes, id }) => {
	const {title,des,btn} =attributes?.styles || {}


	const mainSl = `#${id}`;


	return <style dangerouslySetInnerHTML={{
		__html: `
		
		${mainSl} {
		.bph-btn--primary{
		color:${btn?.color};
		background:${btn?.bg};
		}
		.bph-hero__title{
		color:${title};
		}
		.bph-hero__subtitle{
		color:${des};
		}
		}

	`}} />;
}
export default Style;